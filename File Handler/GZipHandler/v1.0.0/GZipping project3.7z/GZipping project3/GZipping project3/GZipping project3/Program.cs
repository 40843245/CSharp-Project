﻿using GZipping_project3.Utilities.classes.zip.GZipCoreHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GZipping_project3
{
    class Program
    {
        static void Main(string[] args)
        {
			string[] filenameArray = new string[]{
				@"D:\114年KM由所屬公司享有著作財產權與著作人格權同意書.pdf",
				@"D:\114年普查人員保密切結書.pdf"
			};
			List<string> filenameList = new List<string>();

			filenameList = filenameArray.ToList();

			string destinationDirectory = @"D:\test folder";
			string zipFileNameWithoutExtension = "_1";
			string zipFileExtension = ".zip";
			string password = "123";

			GZipCoreHandler gZipHanlder = new GZipCoreHandler(
				filenameList,
				destinationDirectory,
				zipFileNameWithoutExtension,
				zipFileExtension,
				password
			);

			gZipHanlder.Compress();
		}
    }
}
