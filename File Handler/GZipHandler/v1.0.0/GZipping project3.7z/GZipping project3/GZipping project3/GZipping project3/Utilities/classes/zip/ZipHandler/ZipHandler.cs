﻿using GZipping_project3.Utilities.classes.path.PathHandler;
using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GZipping_project3.Utilities.classes.zip.ZipHandler
{
    public static class ZipHandler
    {
        public static void Compress(
             List<string> fileNameList,
            string zipFilePath,
            string password = ""
        )
        {
            try
            {
                PathHandler.CreateFile(zipFilePath);

                using (FileStream fileStream = File.Open(zipFilePath, FileMode.Open))
                {
                    using (ZipOutputStream s = new ZipOutputStream(fileStream))
                    {

                        s.SetLevel(9); // 0 - store only to 9 - means best compression

                        if (String.IsNullOrEmpty(password) == false)
                        {
                            s.Password = password;
                        }

                        byte[] buffer = new byte[4096];

                        foreach (string fileName in fileNameList)
                        {

                            Console.WriteLine(fileName);
                            // Using GetFileName makes the result compatible with XP
                            // as the resulting path is not absolute.
                            var entry = new ZipEntry(Path.GetFileName(fileName));

                            // Setup the entry data as required.

                            // Crc and size are handled by the library for seakable streams
                            // so no need to do them here.

                            // Could also use the last write time or similar for the file.
                            entry.DateTime = DateTime.Now;
                            s.PutNextEntry(entry);

                            using (FileStream fs = File.OpenRead(fileName))
                            {
                                // Using a fixed size buffer here makes no noticeable difference for output
                                // but keeps a lid on memory usage.
                                int sourceBytes;
                                do
                                {
                                    sourceBytes = fs.Read(buffer, 0, buffer.Length);
                                    s.Write(buffer, 0, sourceBytes);
                                } while (sourceBytes > 0);
                            }
                        }

                        // Finish/Close arent needed strictly as the using statement does this automatically

                        // Finish is important to ensure trailing information for a Zip file is appended.  Without this
                        // the created file would be invalid.
                        s.Finish();

                        // Close is important to wrap things up and unlock the file.
                        s.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception during processing {0}", ex);

                // No need to rethrow the exception as for our purposes its handled.
            }
        }
    }
}
