﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace GZipping_project3.Utilities.classes.zip.GZipCoreHandler
{
    public class GZipCoreHandler
    {
        List<string> _fileNameList;
        string _destinationDirectory;
        string _zipFileNameWithoutExtension;
        string _zipFileExtension;
        string _zipFileName;
        string _zipFilePath;
        string _password;
        public GZipCoreHandler(
            List<string> fileNameList,
            string destinationDirectory,
            string zipFileNameWithoutExtension,
            string zipFileExtension,
            string password = ""
        )
        {
            this.Init(
              fileNameList,
              destinationDirectory,
              zipFileNameWithoutExtension,
              zipFileExtension,
              password
           );
        }
        public GZipCoreHandler(
            string fileNameStrId,
            string destinationDirectory,
            string zipFileNameWithoutExtension,
            string zipFileExtension,
            char separator = ',',
            string password = ""
        )
        {
            List<string> fileNameList = fileNameStrId.Split(separator).ToList();
            this.Init(
              fileNameList,
              destinationDirectory,
              zipFileNameWithoutExtension,
              zipFileExtension,
              password
           );
        }
        private void Init(
            List<string> fileNameList,
            string destinationDirectory,
            string zipFileNameWithoutExtension,
            string zipFileExtension,
            string password
        )
        {
            this._fileNameList = fileNameList;
            this._destinationDirectory = destinationDirectory;
            this._zipFileNameWithoutExtension = zipFileNameWithoutExtension;
            this._zipFileExtension = zipFileExtension;
            this._zipFileName = this._zipFileNameWithoutExtension + this._zipFileExtension;
            this._zipFilePath = System.IO.Path.Combine(this._destinationDirectory, this._zipFileName);
            this._password = password;
        }
        public void Compress()
        {
            GZipping_project3.Utilities.classes.zip.ZipHandler.ZipHandler.Compress(
                this._fileNameList,
                this._zipFilePath,
                this._password
            );
        }
    }
}
