﻿using System;
using System.IO;

namespace GZipping_project3.Utilities.classes.path.PathHandler
{
    public static class PathHandler
    {
        /// <summary>
        /// create a new file named `<fullpath>` when file does NOT exist.
        /// 
        /// otherwise, nothing to do.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static void CreateFile(
            string fullpath
        )
        {

            if (!File.Exists(fullpath))
            {
                using (var stream = File.Create(fullpath))
                {

                }
            }
        }
    }
}
