﻿using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using XmlReader_project1.test_code;
using XmlReader_project1.Utilities.classes.data_handling.FileDataHandler;
using XmlReader_project1.Utilities.classes.data_handling.MemoryStreamHandler;
using XmlReader_project1.Utilities.classes.DirectoryHandler;
using XmlReader_project1.Utilities.classes.FileContentFetcher;
using XmlReader_project1.Utilities.classes.FileExtensionHandler;
using XmlReader_project1.Utilities.classes.FileHandler;
using XmlReader_project1.Utilities.classes.FullPathHandler;
using XmlReader_project1.Utilities.classes.XmlHandler;
using XmlReader_project1.Utilities.classes.ZipHandler;
using XmlReader_project1.Utilities.enums;

namespace XmlReader_project1
{
    class Program
    {
        static void Main(string[] args)
        {
            test26();
        }

        /// <summary>
        /// test method
        /// </summary>

        static void test26()
        {
            string nowTimestamp = DateTime.Now.ToString(DateTimeFormatEnum.TIMESTAMP);

            string sourceFileFullPath = @"D:\data folder\input folder\EventSample.ods";
            string tempSourceFileFullPath = System.IO.Path.ChangeExtension(sourceFileFullPath, ".zip");
            string targetEntryName = @"content.xml";

            string sourceFileDirectory = System.IO.Path.GetDirectoryName(sourceFileFullPath);
            string tempOldEntryFullPath = System.IO.Path.Combine(sourceFileDirectory, targetEntryName);
            string tempEntryFullPath = FullPathHandler.InsertStringBeforeExtension(tempOldEntryFullPath,"_"+nowTimestamp);
            
            Console.WriteLine($"tempEntryFullPath:\"{tempEntryFullPath}\"");
            
            FileHandler.Copy(sourceFileFullPath, tempSourceFileFullPath);
            Console.WriteLine($"After copy the file from \"{sourceFileFullPath}\" to \"{tempSourceFileFullPath}\"");

            ZipHandler zipHandler = new ZipHandler(
                tempSourceFileFullPath
            );

            zipHandler.CopyEntry(tempEntryFullPath,targetEntryName);           
            Console.WriteLine($"After copy the entry \"{targetEntryName}\" from \"{tempSourceFileFullPath}\" zip file to \"{tempEntryFullPath}\"");

            using (MemoryStream memoryStream = MemoryStreamHandler.GetMemoryStreamFromFileFullPath(tempEntryFullPath))
            {
                string plainText = MemoryStreamHandler.GetPlainTextFromMemoryStream(memoryStream);
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine($"plainText:");
                Console.WriteLine(plainText);
                Console.WriteLine();
                Console.WriteLine();
            }
            
            zipHandler.RemoveEntry(targetEntryName);
            Console.WriteLine($"After removing entry by name \"{targetEntryName}\",");

            Console.WriteLine("current zipHandler have these entries:");
            zipHandler.PrintEntries();
            
            zipHandler.AddEntry(tempEntryFullPath, targetEntryName);
            Console.WriteLine($"After adding entry \"{tempEntryFullPath}\" and rename it \"{targetEntryName}\",");

            Console.WriteLine("current zipHandler have these entries:");
            zipHandler.PrintEntries();

            DirectoryHandler.DeleteFileOrFolder(tempEntryFullPath);
            Console.WriteLine($"After deleting file or folder \"{tempEntryFullPath}\",");

            zipHandler.Dispose();
            Console.WriteLine($"zipHandler instance was disposed.");
        }
    }
}
