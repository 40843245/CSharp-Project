﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.enums
{
    /// <summary>
    /// stimulated as an enum class that enumerate about format of file extension. 
    /// </summary>
    public static class FileExtensionEnum
    {
        public static string ZIP = ".zip";
        public static string SEVEN_Z = ".7z";
    }
}
