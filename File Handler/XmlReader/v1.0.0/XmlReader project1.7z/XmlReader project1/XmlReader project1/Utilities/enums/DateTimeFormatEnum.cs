﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.enums
{
    /// <summary>
    /// stimulated as an enum class that enumerate about format of DateTime.  
    /// </summary>
    public static class DateTimeFormatEnum
    {
        public static string TIMESTAMP = "yyyyMMddHHmmss";
    }
}
