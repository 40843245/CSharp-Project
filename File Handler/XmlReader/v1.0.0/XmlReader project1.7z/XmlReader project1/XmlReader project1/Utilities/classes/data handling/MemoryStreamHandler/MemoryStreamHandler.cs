﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.classes.data_handling.MemoryStreamHandler
{
    /// <summary>
    /// utility class that handles MemoryStream.
    /// </summary>
    public static class MemoryStreamHandler
    {
        /// <summary>
        /// get MemoryStream from full path `sourceFileFullPath`.
        /// </summary>
        /// <param name="sourceFilFullPath"></param>
        /// <returns></returns>
        public static MemoryStream GetMemoryStreamFromFileFullPath(string sourceFileFullPath)
        {
            string plainText = FileDataHandler.FileDataHandler.GetText(sourceFileFullPath);
            MemoryStream memoryStream = MemoryStreamHandler.GetMemoryStreamGivenPlainText(plainText);
            return memoryStream;
        }

        /// <summary>
        /// get MemoryStream with plain text `plainText`.
        /// </summary>
        /// <param name="plainText"></param>
        /// <returns></returns>
        public static MemoryStream GetMemoryStreamGivenPlainText(string plainText)
        {
            UnicodeEncoding uniEncoding = new UnicodeEncoding();
            byte[] byteArray1 = uniEncoding.GetBytes(plainText);

            MemoryStream memoryStream = new MemoryStream(byteArray1.Length);
            memoryStream.Write(byteArray1, 0, byteArray1.Length);
            return memoryStream;
        }

        /// <summary>
        /// get plain text from MemoryStream `memoryStream`.
        /// </summary>
        /// <param name="memoryStream"></param>
        /// <returns></returns>
        public static string GetPlainTextFromMemoryStream(MemoryStream memoryStream)
        {
            UnicodeEncoding uniEncoding = new UnicodeEncoding();
            memoryStream.Position = 0; // Reset stream position to the beginning (important!)

            using (var reader = new StreamReader(memoryStream, uniEncoding))
            {
                return reader.ReadToEnd();
            }
        }
    }
}
