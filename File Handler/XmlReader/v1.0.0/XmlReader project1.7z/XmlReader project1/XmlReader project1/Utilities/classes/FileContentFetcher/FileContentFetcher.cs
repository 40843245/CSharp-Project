﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlReader_project1.Utilities.classes.DirectoryHandler;
using XmlReader_project1.Utilities.enums;

namespace XmlReader_project1.Utilities.classes.FileContentFetcher
{
    /// <summary>
    /// utility class that get full path of file given `_targetName` in archive file whose name is `_fileName`.
    /// </summary>
    public class FileContentFetcher
    {
        string _fileName;
        string _targetName;

        string _tempFileName;
        string _decompressedFolderDirectory = null;
        string _DecompressedFolderDirectory
        {
            get
            {
                string tempFileName = this._tempFileName;
                if (String.IsNullOrEmpty(tempFileName))
                {
                    throw new ArgumentNullException();
                }
                string parentDirectory = System.IO.Path.GetDirectoryName(tempFileName);
                string tempFileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(tempFileName);
                string destinationFolderDirectory = System.IO.Path.Combine(parentDirectory, tempFileNameWithoutExtension);
                return destinationFolderDirectory;
            }
        }

        string _TargetFileName
        {
            get
            {
                string tempFileName = this._tempFileName;
                if (String.IsNullOrEmpty(tempFileName))
                {
                    throw new ArgumentNullException();
                }
                string decompressedFolderDirectory = this._DecompressedFolderDirectory;
                string specificChild = DirectoryHandler.DirectoryHandler.GetChild(decompressedFolderDirectory, this._targetName);
                return specificChild;
            }
        }
        public FileContentFetcher(
            string fileName,
            string targetName
        )
        {
            this.Init(
                fileName,
                targetName
            );
        }

        public void Init(
            string fileName,
            string targetName
        )
        {
            string nowTimestamp = DateTime.Now.ToString(DateTimeFormatEnum.TIMESTAMP);
            this._fileName = fileName;
            this._targetName = targetName;
            string sourceFileDirectory = System.IO.Path.GetDirectoryName(this._fileName);
            string sourceFileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(this._fileName);
            string sourceFileExtension = ".zip";
            string sourceFileName = sourceFileNameWithoutExtension + "_" + nowTimestamp + sourceFileExtension ;
            string sourceFileFullPath = System.IO.Path.Combine(sourceFileDirectory, sourceFileName);
            this._tempFileName = sourceFileFullPath;
            this._decompressedFolderDirectory = this._DecompressedFolderDirectory;
        }

        /// <summary>
        /// main method
        /// 
        /// get full path of file given `_targetName` in archive file whose name is `_fileName`.
        /// </summary>
        /// <returns></returns>
        public string GetContentPath()
        {
            this.CopyFile();
            this.ExtractFile();
            string targetFileName = this._TargetFileName;
            if (System.IO.File.Exists(targetFileName))
            {
                return targetFileName;
            }
            throw new Exception($"The file {targetFileName} does exist.");
        }

        /// <summary>
        /// copy file.
        /// </summary>
        private void CopyFile()
        {    
          System.IO.File.Copy(this._fileName, this._tempFileName, true);
        }

        /// <summary>
        /// extract file.
        /// </summary>
        private void ExtractFile()
        {
            System.IO.Compression.ZipFile.ExtractToDirectory(this._tempFileName, this._decompressedFolderDirectory);
        }

        /// <summary>
        /// dispose it. 
        /// 
        /// always invoke this method after the instance will never be used 
        /// 
        /// since invoking some method will generate temporary file or folder.
        /// </summary>

        public void Dispose()
        {
           if(this._decompressedFolderDirectory != null)
           {
                System.IO.File.Delete(this._tempFileName);
                DirectoryHandler.DirectoryHandler.DeleteDirectory(this._decompressedFolderDirectory);
            }
        }
    }
}
