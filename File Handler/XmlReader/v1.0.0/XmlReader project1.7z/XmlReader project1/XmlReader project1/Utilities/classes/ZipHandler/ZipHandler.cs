﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlReader_project1.Utilities.classes.data_handling.MemoryStreamHandler;
using XmlReader_project1.Utilities.enums;

namespace XmlReader_project1.Utilities.classes.ZipHandler
{
    /// <summary>
    /// > [!NOTE]
    /// > fileFullPath must have an extension as archive (uncompressed) file  
    /// </summary>
    /// <param name="fileFullPath"></param>
    public class ZipHandler
    {
        string _fileFullPath;
        string _nowTimeStamp;
        string _originalFileFullPath;
        string _tempDecompressedFileFullPath;
        string _tempDecompressedFileDirectory;

        /// <summary>
        /// > [!NOTE]
        /// > fileFullPath must have an extension as archive (uncompressed) file  
        /// </summary>
        /// <param name="fileFullPath"></param>
        public ZipHandler(
            string fileFullPath
        )
        {
            this.Init(
                fileFullPath
            );
        }

        private void Init(
            string fileFullPath
        )
        {
            this._nowTimeStamp = DateTime.Now.ToString(DateTimeFormatEnum.TIMESTAMP);
            this._fileFullPath = fileFullPath;
            this._originalFileFullPath = this._fileFullPath;
            this._tempDecompressedFileFullPath = FullPathHandler.FullPathHandler.InsertStringBeforeExtension(this._originalFileFullPath, "_" + this._nowTimeStamp);
            this._tempDecompressedFileDirectory = FullPathHandler.FullPathHandler.RemoveExtension(this._tempDecompressedFileFullPath);
        }

        /// <summary>
        /// compress the archive (undecompressed) file
        /// </summary>
        public void Compress()
        {
            System.IO.Compression.ZipFile.CreateFromDirectory(this._fileFullPath, this._tempDecompressedFileFullPath);
        }

        /// <summary>
        /// decompress the archive (undecompressed) file.
        /// </summary>
        public void Decompress()
        {
            System.IO.Compression.ZipFile.ExtractToDirectory(this._fileFullPath, this._tempDecompressedFileDirectory);
        }

        /// <summary>
        /// check has an entry whose name is `entryName`
        /// 
        /// under archive (undecompressed) file whose full path is `this._originalFileFullPath`.
        /// </summary>
        /// <param name="entryName"></param>
        /// <returns></returns>
        public bool HasEntry(string entryName)
        {
            this.Decompress();
            string tempDecompressedFileDirectory = this._tempDecompressedFileDirectory;
            bool hasSpecificChild = DirectoryHandler.DirectoryHandler.HasChild(this._tempDecompressedFileDirectory, entryName);
            // Don't forget to delete created temporary file and folder.
            DirectoryHandler.DirectoryHandler.DeleteFileOrFolder(this._originalFileFullPath);
            System.IO.Compression.ZipFile.CreateFromDirectory(this._tempDecompressedFileDirectory, this._originalFileFullPath);
            DirectoryHandler.DirectoryHandler.DeleteFileOrFolder(this._tempDecompressedFileDirectory);
            return hasSpecificChild;
        }

        /// <summary>
        /// add entry from `sourceFileFullPath` 
        /// 
        /// under archive (undecompressed) file whose full path is `this._originalFileFullPath`.
        /// 
        /// And rename it as `childName`.
        /// 
        /// > [!WARNING]
        /// > If the `childName` is the name of one of entry 
        /// > 
        /// > under archive (undecompressed) file whose full path is `this._originalFileFullPath`,
        /// > 
        /// > then it will be overwritten.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="childName"></param>
        public void AddEntry(string sourceFileFullPath,string childName)
        {
            this.Decompress();
            string tempDecompressedFileDirectory = this._tempDecompressedFileDirectory;
            DirectoryHandler.DirectoryHandler.AddChild(sourceFileFullPath, this._tempDecompressedFileDirectory, childName);

            // Don't forget to delete created temporary file and folder.
            this.DeleteTempFileAndFolder();
        }

        /// <summary>
        /// get full path of entry whose name is `entryName` 
        /// 
        /// under archive (undecompressed) file whose full path is `this._originalFileFullPath`.
        /// </summary>
        /// <param name="entryName"></param>
        /// <returns></returns>
        public string GetEntryFullPathByName(string entryName)
        {
            bool hasEntry = this.HasEntry(entryName);
            if (!hasEntry)
            {
                return null;
            }

            this.Decompress();
            string tempDecompressedFileDirectory = this._tempDecompressedFileDirectory;

            string tempChildName = DirectoryHandler.DirectoryHandler.GetChild(this._tempDecompressedFileDirectory, entryName);
            string newParentDirectory = this._originalFileFullPath;
            string renamedChildName = FullPathHandler.FullPathHandler.RenameParentDirectory(tempChildName, newParentDirectory);

            // Don't forget to delete created temporary file and folder.
            this.DeleteTempFileAndFolder();
            return renamedChildName;
        }

        /// <summary>
        /// remove entry whose full path is `destinationFullPath` 
        /// 
        /// under archive (undecompressed) file whose full path is `this._originalFileFullPath` 
        /// </summary>
        /// <param name="entryName"></param>
        public void RemoveEntry(string entryName)
        {
            this.Decompress();
            DirectoryHandler.DirectoryHandler.DeleteChild(this._tempDecompressedFileDirectory, entryName);

            // Don't forget to delete created temporary file and folder.
            this.DeleteTempFileAndFolder();
        }

        /// <summary>
        /// copy entry whose full path is `destinationFullPath` 
        /// 
        /// under archive (undecompressed) file whose full path is `this._originalFileFullPath` 
        /// 
        /// if the entry does not exist.
        /// 
        /// And rename the entry as `entryName`. 
        /// </summary>
        /// <param name="destinationFullPath"></param>
        /// <param name="entryName"></param>
        public void CopyEntry(string destinationFullPath,string entryName)
        {
            bool hasEntry = this.HasEntry(entryName);
            if (!hasEntry)
            {
                return;
            }

            this.Decompress();
            string tempDecompressedFileDirectory = this._tempDecompressedFileDirectory;

            // NOTE that `tempChildName` is a full path.
            string tempChildName = DirectoryHandler.DirectoryHandler.GetChild(this._tempDecompressedFileDirectory, entryName);

            // Copy the entry from `tempChildName` file (represented as a full path) to `destinationFullPath` file (represented as a full path).
            FileHandler.FileHandler.Copy(tempChildName, destinationFullPath);

            // Don't forget to delete created temporary file and folder.
            this.DeleteTempFileAndFolder();
        }

        /// <summary>
        /// print all entries in zip file whose full path is `this._fileFullPath`.
        /// </summary>
        public void PrintEntries()
        {
            using (ZipArchive zipArchive = ZipFile.Open(this._fileFullPath, ZipArchiveMode.Read))
            {
                foreach (ZipArchiveEntry entry in zipArchive.Entries)
                {
                    Console.WriteLine(entry);
                }
            }
        }

        /// <summary>
        /// delete created temporary file and folder.
        /// </summary>
        public void DeleteTempFileAndFolder()
        {

            DirectoryHandler.DirectoryHandler.DeleteFileOrFolder(this._originalFileFullPath);
            System.IO.Compression.ZipFile.CreateFromDirectory(this._tempDecompressedFileDirectory, this._originalFileFullPath);
            DirectoryHandler.DirectoryHandler.DeleteFileOrFolder(this._tempDecompressedFileDirectory);
        }

        /// <summary>
        /// helper method of dispose method.
        /// </summary>
        public void DeleteSelf()
        {
            DirectoryHandler.DirectoryHandler.DeleteFileOrFolder(this._originalFileFullPath);
        }

        /// <summary>
        /// dispose it.
        /// 
        /// always invoke this method if the instance will never will be used
        /// 
        /// since some temporary files or folders will be generated.
        /// </summary>
        public void Dispose()
        {
            this.DeleteSelf();
        }
    }
}
