﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XmlReader_project1.Utilities.enums;

namespace XmlReader_project1.Utilities.classes.FullPathHandler
{
    /// <summary>
    /// utility class that handles a full path (NOT full path of file).
    /// </summary>
    public static class FullPathHandler
    {
        /// <summary>
        /// check the full path `sourceFileFullPath` is format of archive file (for example `*.zip`, `*.7z`) 
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool IsZipFile(string sourceFileFullPath)
        {
            string sourceFileNameWithoutExtension = System.IO.Path.GetExtension(sourceFileFullPath);
            if (sourceFileNameWithoutExtension == FileExtensionEnum.ZIP)
            {
                return true;
            }

            if (sourceFileNameWithoutExtension == FileExtensionEnum.SEVEN_Z)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// check `sourceFileFullPath` has extension.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool HasExtension(string sourceFileFullPath)
        {
            return System.IO.Path.HasExtension(sourceFileFullPath);
        }

        /// <summary>
        /// given a full path `sourceFileFullPath`, 
        /// 
        /// replace the file extension of `sourceFileFullPath` with new extension `newExtension`,
        /// 
        /// then return it.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="newExtension"></param>
        /// <returns></returns>
        public static string GetFullFileWithNewExtension(string sourceFileFullPath,string newExtension)
        {
            bool hasExtension = FullPathHandler.HasExtension(sourceFileFullPath);
            if (hasExtension == false)
            {
                throw new ArgumentException($"The sourceFileFullPath \"{sourceFileFullPath}\" does not have extension");
            }

            bool isValidExtension = FileExtensionHandler.FileExtensionHandler.IsValidExtension(newExtension);
            if (isValidExtension == false)
            {
                throw new ArgumentException($"The newExtension \"{newExtension}\" is a not valid extension.");
            }

            string sourceFileDirectory = System.IO.Path.GetDirectoryName(sourceFileFullPath);
            string sourceFileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(sourceFileFullPath);
            string newFileFullPath = System.IO.Path.Combine(sourceFileDirectory, sourceFileNameWithoutExtension + newExtension);
            return newFileFullPath;
        }

        /// <summary>
        /// given full path `sourceFileFullPath`,
        /// 
        /// remove file extension of `sourceFileFullPath`,
        /// 
        /// then return it.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static string RemoveExtension(string sourceFileFullPath)
        {
            string newFileFullPathWithoutExtension = System.IO.Path.ChangeExtension(sourceFileFullPath, null);
            return newFileFullPathWithoutExtension;
        }

        /// <summary>
        /// given full path `sourceFileFullPath` and a string `insertedName`,
        /// 
        /// insert the string `insertedName` between extension,
        /// 
        /// then return it.
        /// 
        /// For example:
        /// 
        /// ```
        /// string sourceFileFullPath = @"D:\data folder\input folder\EventSample.ods";
        /// string insertedName = @"_1";
        /// string newFileFullPath = FullPathHandler.InsertStringBeforeExtension(sourceFileFullPath,insertedName);
        /// Console.WriteLine(newFileFullPath);
        /// ```
        /// 
        /// will output
        /// 
        /// ```
        /// D:\data folder\input folder\EventSample_1.ods
        /// ```
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="insertedName"></param>
        /// <returns></returns>
        public static string InsertStringBeforeExtension(string sourceFileFullPath,string insertedName)
        {
            string sourceFileDirectory = System.IO.Path.GetDirectoryName(sourceFileFullPath);
            string sourceFileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(sourceFileFullPath);
            string sourceFileExtension = System.IO.Path.GetExtension(sourceFileFullPath);
            string newFileFullPath = System.IO.Path.Combine(sourceFileDirectory, sourceFileNameWithoutExtension + insertedName + sourceFileExtension);
            return newFileFullPath;
        }

        /// <summary>
        /// given full path `sourceFileFullPath` and a string `newParentName`,
        /// 
        /// change parent directory of `sourceFileFullPath` as `newParentName`,
        /// 
        /// then return it.
        /// 
        /// > [!NOTE]
        /// > it will not rename the file name (though the method name starts with `Rename`) sorry for unclear naming convention.
        /// 
        /// For example,
        /// 
        /// ```
        /// string sourceFileFullPath = @"D:\data folder\input folder\EventSample.ods";
        /// string newParentName = @"input folder2";
        /// string newFileFullPath = FullPathHandler.RenameParentDirectory(sourceFileFullPath,newParentName);
        /// Console.WriteLine(newFileFullPath);
        /// ```
        /// 
        /// will output
        /// 
        /// ```
        /// D:\data folder\input folder2\EventSample.ods
        /// ```
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="newParentName"></param>
        /// <returns></returns>
        public static string RenameParentDirectory(string sourceFileFullPath,string newParentName)
        {
            string directory = System.IO.Path.GetDirectoryName(sourceFileFullPath);
            string filename = System.IO.Path.GetFileName(sourceFileFullPath);
            string parentDirectory = System.IO.Path.GetDirectoryName(directory);
            string grandparentDirectory = System.IO.Path.GetDirectoryName(parentDirectory);
            string newParentDirectory = System.IO.Path.Combine(grandparentDirectory, newParentName);

            bool fileExists = System.IO.File.Exists(newParentDirectory);
            if (!fileExists)
            {
                System.IO.File.Create(newParentDirectory);
            }
            bool directoryExists = System.IO.Directory.Exists(newParentDirectory);
            if (!fileExists && !directoryExists)
            {
                System.IO.Directory.CreateDirectory(newParentDirectory); // Creates intermediate directories if needed.
            }

            string newFilePath = System.IO.Path.Combine(newParentDirectory, filename);
            return newFilePath;
        }
    }
}
