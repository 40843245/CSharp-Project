﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.classes.DirectoryHandler
{
    /// <summary>
    /// utility class that handles about directory
    /// </summary>
    public static class DirectoryHandler
    {
        /// <summary>
        /// return true iff `sourceFileFullPath` exists and it is a directory. (validate by `System.IO.FileAttributes`)
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool IsDirectory(string sourceFileFullPath)
        {
            bool exists = DirectoryHandler.Exists(sourceFileFullPath);
            if (exists == false)
            {
                return false;
            }

            System.IO.FileAttributes fileAttr = System.IO.File.GetAttributes(sourceFileFullPath);
            return (fileAttr & System.IO.FileAttributes.Directory) == System.IO.FileAttributes.Directory;
        }

        /// <summary>
        /// return true iff `sourceFileFullPath` exists and it is a file. (validate by `System.IO.FileAttributes`)
        /// 
        /// > [!NOTE]
        /// > it is not equivalent to negation of `IsDirectory` method call.  
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool IsFile(string sourceFileFullPath)
        {
            bool exists = DirectoryHandler.Exists(sourceFileFullPath);
            if (exists == false)
            {
                return false;
            }

            return !DirectoryHandler.IsDirectory(sourceFileFullPath);
        }

        /// <summary>
        /// return true iff `sourceFileFullPath` is a directory or file. 
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static bool Exists(string sourceFileFullPath)
        {
            if (System.IO.Directory.Exists(sourceFileFullPath))
            {
                return true;
            }

            if (System.IO.File.Exists(sourceFileFullPath))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// add a file under directory.
        /// 
        /// add a file whose full path is `sourceFileFullPath` under directory `destinationDirectory`,
        /// 
        /// then rename the new file name (with extension) (exclusive of directory of new file name) as `childName`
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="childName"></param>
        public static void AddChild(
            string sourceFileFullPath,
            string destinationDirectory,
            string childName
        )
        {
            string destinationFileFullPath = System.IO.Path.Combine(destinationDirectory,childName);

            bool exists = System.IO.Directory.Exists(destinationDirectory);
            if (!exists)
            {
                 System.IO.Directory.CreateDirectory(destinationDirectory);
            }

            FileHandler.FileHandler.Copy(sourceFileFullPath, destinationFileFullPath);

            return;
        }

        /// <summary>
        /// delete directory.
        /// 
        /// delete all children of `sourceDirectory`,
        /// 
        /// then delete the folder `sourceDirectory`
        /// </summary>
        /// <param name="sourceDirectory"></param>
        public static void DeleteDirectory(string sourceDirectory)
        {
            DirectoryHandler.DeleteChildren(sourceDirectory);
            System.IO.Directory.Delete(sourceDirectory);
        }

        /// <summary>
        /// delete specific child of a directory.
        /// 
        /// delete specific child whose name is `childName` of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="childName"></param>
        public static void DeleteChild(string sourceDirectory, string childName)
        {
            string fileFullPath = System.IO.Path.Combine(sourceDirectory, childName);
            DirectoryHandler.DeleteFileOrFolder(fileFullPath);
        }

        /// <summary>
        /// delete all children of a directory.
        /// 
        /// delete all children of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        public static void DeleteChildren(string sourceDirectory)
        {
            List<string> children = DirectoryHandler.FindChildren(sourceDirectory);
            int childrenLength = children.Count();
            for (int i = 0; i < childrenLength; i++)
            {
                string child = children[i];
                DirectoryHandler.DeleteFileOrFolder(child);
            }
        }

        /// <summary>
        /// delete a file or folder.
        /// 
        /// delete a file or folder whose full path is `sourceFileFullPath`.
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        public static void DeleteFileOrFolder(string sourceFileFullPath)
        {
            bool isDirectory = DirectoryHandler.IsDirectory(sourceFileFullPath);

            if (isDirectory)
            {
                DirectoryHandler.DeleteDirectory(sourceFileFullPath);
            }
            else
            {
                System.IO.File.Delete(sourceFileFullPath);
            }
        }

        /// <summary>
        /// find all children of a directory.
        /// 
        /// find all children of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <returns></returns>
        public static List<string> FindChildren(string sourceDirectory)
        {
            List<string> children = new List<string>();
            List<string> tempVariable = new List<string>();
            tempVariable = System.IO.Directory.GetFiles(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            tempVariable = System.IO.Directory.GetDirectories(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            return children;
        }

        /// <summary>
        /// get specific child of a directory.
        /// 
        /// get specific child whose file name is `targetFileName` of a directory `sourceDirectory`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="targetFileName"></param>
        /// <returns></returns>
        public static string GetChild(string sourceDirectory,string targetFileName)
        {
            bool hasSpecificChild = DirectoryHandler.HasChild(sourceDirectory,targetFileName);

            if (hasSpecificChild)
            {
                string targetFileFullPath = System.IO.Path.Combine(sourceDirectory,targetFileName);
                return targetFileFullPath;
            }

            return null;
        }

        /// <summary>
        /// check a directory has a specific child.
        /// 
        /// check a directory `sourceDirectory` has a specific child whose name is `targetFileName`.
        /// </summary>
        /// <param name="sourceDirectory"></param>
        /// <param name="targetFileName"></param>
        /// <returns></returns>
        public static bool HasChild(string sourceDirectory, string targetFileName)
        {
            bool exists = DirectoryHandler.Exists(sourceDirectory);
            if (exists == false)
            {
                return false;
            }

            List<string> children = DirectoryHandler.FindChildren(sourceDirectory);
            bool hasSpecificChild = children.Exists(
                child => targetFileName.Equals(System.IO.Path.GetFileName(child))
            ); 
            return hasSpecificChild;
        }
    }
}
