﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XmlReader_project1.Utilities.classes.XmlHandler
{
    /// <summary>
    /// utility class that handles Xml data given `_fileName`.
    /// 
    /// > [!CAUTION]
    /// > It must be xml file (i.e. a file name that has extension `.xml`).
    /// </summary>
    public class XmlHandler
    {
        string _fileName;
        public XmlHandler(
            string fileName
        )
        {
            this.Init(
                fileName
            );
        }

        private void Init(
            string fileName    
        )
        {
            this._fileName = fileName;
        }

        /// <summary>
        /// load `this._fileName` as xml and return `XmlDocument`.
        /// </summary>
        /// <returns></returns>
        public XmlDocument GetXmlDocument()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(this._fileName);
            return xmlDocument;
        }
    }
}
