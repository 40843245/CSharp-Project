﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.classes.data_handling.FileDataHandler
{
    /// <summary>
    /// utility class that handles data of file given full path of file.
    /// </summary>
    public static class FileDataHandler
    {
        /// <summary>
        /// given a full path `sourceFileFullPath`, return data represented as plain text.
        /// 
        /// > [!CAUTION]
        /// >
        /// > `sourceFileFullPath` must be a existing file. 
        /// > 
        /// > Otherwise, it will throw `FileNotFoundException`.
        /// 
        /// 
        /// </summary>
        /// <param name="sourceFileFullPath"></param>
        /// <returns></returns>
        public static string GetText(string sourceFileFullPath)
        {
            bool fileExists = System.IO.File.Exists(sourceFileFullPath);
            if (fileExists)
            {
                string plainText = System.IO.File.ReadAllText(sourceFileFullPath);
                return plainText;
            }

            throw new FileNotFoundException($"The file \"{sourceFileFullPath}\" is not found.");
        }

        /// <summary>
        /// given a full path `destinationFileFullPath`, write plain text to full path of file -- `destinationFileFullPath`.
        /// </summary>
        /// <param name="plainText"></param>
        /// <param name="destinationFileFullPath"></param>
        public static void WriteText(string plainText, string destinationFileFullPath)
        {
            using (StreamWriter streamWriter = new StreamWriter(destinationFileFullPath,true))
            {
                streamWriter.Write(plainText);
            }
        }
    }
}
