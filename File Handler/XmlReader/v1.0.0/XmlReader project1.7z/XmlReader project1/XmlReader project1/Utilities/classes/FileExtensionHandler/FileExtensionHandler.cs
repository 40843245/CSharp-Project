﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlReader_project1.Utilities.classes.FileExtensionHandler
{
    /// <summary>
    /// a utility class that handles file extension.
    /// </summary>
    public static class FileExtensionHandler
    {
        /// <summary>
        /// check `fileExtension` is a valid format of extension.
        /// </summary>
        /// <param name="fileExtension"></param>
        /// <returns></returns>
        public static bool IsValidExtension(string fileExtension)
        {
            bool startWithDot = fileExtension.StartsWith(".");  
            if (startWithDot == false)
            {
                return false;
            }

            int numberOfDot = fileExtension.Count(c => c == '.');
            return numberOfDot == 1;
        }
    }
}
