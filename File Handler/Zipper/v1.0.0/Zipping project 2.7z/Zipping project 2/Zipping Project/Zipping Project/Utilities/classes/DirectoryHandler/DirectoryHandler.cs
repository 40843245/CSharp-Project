﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zipping_Project.Utilities.classes.DirectoryHandler
{
    public static class DirectoryHandler
    {
        public static void DeleteDirectory(string sourceDirectory)
        {
            DirectoryHandler.DeleteChildren(sourceDirectory);
            System.IO.Directory.Delete(sourceDirectory); 
        }

        public static void DeleteChildren(string sourceDirectory)
        {
            List<string> children = DirectoryHandler.FindChildren(sourceDirectory);
            int childrenLength = children.Count();
            for (int i=0;i<childrenLength;i++)
            {
                string child = children[i];
                DirectoryHandler.DeleteFileOrFolder(child);
            }
        } 
        public static void DeleteFileOrFolder(string source)
        {
            System.IO.FileAttributes fileAttr = System.IO.File.GetAttributes(source);
            
            if ((fileAttr & System.IO.FileAttributes.Directory) == System.IO.FileAttributes.Directory)
            {
                DirectoryHandler.DeleteDirectory(source);
            }
            else
            {
                System.IO.File.Delete(source);
            }
        }

        public static List<string> FindChildren(string sourceDirectory)
        {
            List<string> children = new List<string>();
            List<string> tempVariable = new List<string>();
            tempVariable = System.IO.Directory.GetFiles(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            tempVariable = System.IO.Directory.GetDirectories(sourceDirectory).ToList();
            children.AddRange(tempVariable);
            return children;
        }
    }
}
