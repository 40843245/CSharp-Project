﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zipping_Project.Utilities.classes.Zipper
{
    class Zipper
    {
        List<string> _fileNameList;
        string _sourceDirectory;
        string _destinationDirectory;
        string _tempZipDestinationDirectory;
        string _tempFolderDestinationDirectory;
        string _tempZipDestinationFullPath;
        string _ext = ".zip";
        string _zipFileNameWithoutExtenstion;
        string _zipFileExtenstion;


        /// <summary>
        /// Main constructor
        /// </summary>
        /// <param name="fileNameList"></param>
        /// <param name="destinationDirectory"></param>
        public Zipper(
            List<string> fileNameList,
            string destinationDirectory,
            string zipFileNameWithoutExtenstion,
            string zipFileExtenstion
        )
        {
            this.Init(
                fileNameList,
                destinationDirectory,
                zipFileNameWithoutExtenstion,
                zipFileExtenstion
            );
        }

        /// <summary>
        /// Utility constructor
        /// </summary>
        /// <param name="fileNameStrId"></param>
        /// <param name="destinationDirectory"></param>
        /// <param name="separator"></param>
        public Zipper(
           string fileNameStrId,
           string destinationDirectory,
           string zipFileNameWithoutExtenstion,
           string zipFileExtenstion,
           char separator = ','
        )
        {
            List<string> fileNameList = fileNameStrId.Split(separator).ToList();
            this.Init(
                fileNameList,
                destinationDirectory,
                zipFileNameWithoutExtenstion,
                zipFileExtenstion
            );
        }

        /// <summary>
        /// Initialize property
        /// </summary>
        /// <param name="fileNameList"></param>
        /// <param name="destinationDirectory"></param>
        public void Init(
            List<string> fileNameList,
            string destinationDirectory,
            string zipFileNameWithoutExtenstion,
            string zipFileExtenstion
        )
        {
            this._fileNameList = fileNameList;
            this._zipFileNameWithoutExtenstion = zipFileNameWithoutExtenstion;
            this._zipFileExtenstion = zipFileExtenstion;
            this._sourceDirectory = System.IO.Path.GetDirectoryName(fileNameList[0]);
            this._destinationDirectory = destinationDirectory;
            this._tempFolderDestinationDirectory = System.IO.Path.Combine(this._destinationDirectory, "_temp");
            this._tempZipDestinationDirectory = System.IO.Path.Combine(this._destinationDirectory,this._zipFileNameWithoutExtenstion);
            this._tempZipDestinationFullPath = this._tempZipDestinationDirectory+this._zipFileExtenstion;
        }

        /// <summary>
        /// Create a simple zip file. 
        /// 
        /// > [!WARNING]
        /// > Due to the functionality of `System.IO.Compression.ZipFile.CreateFromDirectory` function,
        /// > 
        /// > This function will create a zip file, 
        /// > 
        /// > with `../_1.zip` file 
        /// >
        /// > containing all files in the directory sourceDirectory
        /// >
        /// > where 
        /// >
        /// > sourceDirectory := The absolute directory of fileNameList[0].
        /// 
        /// </summary>
        public void CreateZipFileWithSourceDirectory()
        {
            System.IO.Compression.ZipFile.CreateFromDirectory(this._sourceDirectory, this._tempZipDestinationFullPath); // Zips the directory containing the file.
        }

        /// <summary>
        /// Create zip file with more complex control.
        /// </summary>
        public void CreateZipFileWithDifferentDirectory()
        {
            Directory.CreateDirectory(this._tempFolderDestinationDirectory);
            this.MoveFilesToTempFolder();
            Console.WriteLine($"this._tempZipDestinationFullPath:{this._tempZipDestinationFullPath}");
            System.IO.Compression.ZipFile.CreateFromDirectory(this._tempFolderDestinationDirectory, this._tempZipDestinationFullPath); // Zips the directory containing the file.
            this.DeleteTempFolder();
        }

        private void MoveFilesToTempFolder()
        {
            Console.WriteLine($"this._tempFolderDestinationDirectory:{this._tempFolderDestinationDirectory}");
            int fileNameListLength = this._fileNameList.Count();
            for (int i=0;i<fileNameListLength;i++)
            {
                string fileName = this._fileNameList[i];
                Console.WriteLine($"fileName:{fileName}");
                string destinationFileName = System.IO.Path.Combine(this._tempFolderDestinationDirectory, System.IO.Path.GetFileName(fileName));
                Console.WriteLine($"destinationFileName:{destinationFileName}");
                System.IO.File.Copy(fileName, destinationFileName);
            }
        }

        private void DeleteTempFolder()
        {
            Zipping_Project.Utilities.classes.DirectoryHandler.DirectoryHandler.DeleteDirectory(this._tempFolderDestinationDirectory);
        }
    }
}
