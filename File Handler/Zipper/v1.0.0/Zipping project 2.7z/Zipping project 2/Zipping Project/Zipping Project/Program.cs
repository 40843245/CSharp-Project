﻿using System.IO.Compression;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.AccessControl;
using System.Security.Principal;

namespace Zipping_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] fileNameArray = new string[]{
                @"D:\data folder\input folder\114年KM由所屬公司享有著作財產權與著作人格權同意書.pdf",
                @"D:\data folder\input folder\114年普查人員保密切結書.pdf",
                @"D:\data folder\input folder 2\48939.jpg"
            };

            string zipFileNameWithoutExtenstion = "_2";
            string zipFileExtenstion = ".zip";
            string destinationDirectory = @"D:\data folder\output folder";
            List<string> fileNameList = new List<string>();
            fileNameList.AddRange(fileNameArray);
            var zipper = new Zipping_Project.Utilities.classes.Zipper.Zipper(
                fileNameList, 
                destinationDirectory,
                zipFileNameWithoutExtenstion,
                zipFileExtenstion
            );
            //zipper.CreateZipFileWithSourceDirectory();
            zipper.CreateZipFileWithDifferentDirectory();
        }
    }
}
